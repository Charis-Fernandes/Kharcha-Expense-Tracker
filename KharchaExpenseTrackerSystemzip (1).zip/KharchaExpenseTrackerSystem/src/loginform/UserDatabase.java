/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginform;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Alister Fernandes
 */
public class UserDatabase {
    // Assuming you have some data structure to store user information
    private Map<String, Integer> userToIdMap;

    public UserDatabase() {
        // Initialize your data structure, e.g., a HashMap
        userToIdMap = new HashMap<>();
        // Populate it with user data
        userToIdMap.put("user1", 1);
        userToIdMap.put("user2", 2);
        // Add more users as needed
    }

    // Method to get the user ID based on the username
    private int getUserIdByUsername(String username) {
        // Lookup the user ID in your data structure
        Integer userId = userToIdMap.get(username);
        if (userId != null) {
            return userId; // Return the user ID if found
        } else {
            // Handle the case when the username is not found, e.g., return a default value or throw an exception.
            throw new IllegalArgumentException("User not found: " + username);
        }
    }

    public static void main(String[] args) {
        UserDatabase userDatabase = new UserDatabase();
        String username = "user1"; // Change this to the desired username
        int userId = userDatabase.getUserIdByUsername(username);
        System.out.println("User ID for " + username + " is: " + userId);
    }
}

    
