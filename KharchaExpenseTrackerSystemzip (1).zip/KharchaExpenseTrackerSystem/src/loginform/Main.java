    package loginform;
    import com.toedter.calendar.JDateChooser;
    import java.awt.Color;
    import javax.swing.*;
    import java.awt.event.ActionEvent;
    import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
    import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.TableModel;   
import javax.swing.table.DefaultTableModel;

    
/**
 *
 * @author Alister Fernandes
 */
    public class Main extends javax.swing.JFrame {

           double balance = 0.0;
           double income = 0;
           double expense = 0;
  
           
          
 public Connection connect() {
    Connection connection;
    try {
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/kharchaets", "root", "alister");
    } catch (SQLException e) {
        e.printStackTrace();
        throw new RuntimeException("Failed to establish a database connection.");
    }
    return connection;
}
  public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Connection closed.");
            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception, e.g., log it or throw a custom exception
            }
        }
  }
    

    public Main() throws SQLException {
        ImageIcon icon = new ImageIcon(getClass().getResource("/loginform/icon/kharcha_logo.jpg")); // Adjust the path as needed
        setIconImage(icon.getImage());
         setTitle("KHARCHA: The Expense Tracker");
    
        initComponents();
        
        
    }
    private void addEntry() {
        
        
        
        java.util.Date selectedDate = DateChooser.getDate();
        if (selectedDate == null) {
            JOptionPane.showMessageDialog(this, "Select a Date", "ERROR MESSAGE", JOptionPane.ERROR_MESSAGE);
        return;
        }

    // Format the date to 'YYYY-MM-DD' format
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String date = sdf.format(selectedDate);
        
        

        
       
        String description = descriptionTextField.getText();
        String amountStr = amountTextField.getText();
        String type = Type.getSelectedItem().toString();
        String category = Category.getSelectedItem().toString();
        double amount;
        


        if (amountStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter the Amount", "ERROR MESSAGE", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Enter the Amount", "Invalid Amount Format", JOptionPane.ERROR_MESSAGE);
            return;
        }
         if (type.equals("EXPENSE")) {
             
             expense += amount;
        expenseLabel.setText("₹" + expense);
         }
        else{
             
             income += amount;
                incomeLabel.setText("₹" + income);
                }
        if (type.equals("EXPENSE")) {
            amount *= -1;
        }

        String data[] = {date,description,amountStr,type,category};
        DefaultTableModel model = (DefaultTableModel) entryTable.getModel();
        ExpenseIncomeEntry entry = new ExpenseIncomeEntry(date, description, amount, type);
        model.addRow(data);
        
        
        
        balance = balance + amount;
        balanceLabel.setText("₹" + balance);
        
        
              try {
        Connection connection = connect();
        String insertQuery = "INSERT INTO expenses (date, description, amount, type,category) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
        preparedStatement.setString(1, date);
        preparedStatement.setString(2, description);
        preparedStatement.setDouble(3, amount);
        preparedStatement.setString(4, type);
        preparedStatement.setString(5, category);
        preparedStatement.executeUpdate();
        closeConnection(connection);
    } catch (SQLException e) {
        System.err.println("Error inserting data: " + e.getMessage());

        // Debug prints to see the values
        System.out.println("Date: " + date);
        System.out.println("Description: " + description);
        System.out.println("Amount: " + amount);
        System.out.println("Type: " + type);
        System.out.println("Category: " + category);
    }

        clearInputFields();
    }


    private void clearInputFields() {
        DateChooser.cleanup();
        DateChooser.setDate(null);
        descriptionTextField.setText("");
        amountTextField.setText("");
        
    }
    
    public void adduserEntry(){

        
               try {
                   Connection connection = connect();
                  
                   String insertQuery1 = "INSERT INTO users (balance, expense, income) VALUES (?, ?, ?)";
                   String balance1 = balanceLabel.getText();
                   String expense1 = expenseLabel.getText();
                   String income1 = incomeLabel.getText();
                   
                   PreparedStatement preparedStatement = connection.prepareStatement(insertQuery1);
                   preparedStatement.setString(1, balance1);
                   preparedStatement.setString(2, expense1);
                   
                   preparedStatement.setString(3, income1);
                   
                   preparedStatement.executeUpdate();
               } catch (SQLException ex) {
                   Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
               }
    }
    
    public void retrieveData(){
        try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kharchaets", "root", "alister");
        Statement st = con.createStatement();
        String query = "select * from users";
        ResultSet rs = st.executeQuery(query);
        ResultSetMetaData rsmd = rs.getMetaData();
        
        while (rs.next()) {
            int user_id = rs.getInt(1);
            String username = rs.getString(2);
            String password = rs.getString(3);
            
           // String type = rs.getString(5);
           // String category = rs.getString(7);

        }
        st.close();
        con.close();
    } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
              
        }
     
    }
    private void addbalance(){
        try {
        Connection connection = connect();
        String insertQuery = "INSERT INTO users (balance, expense, income) VALUES ('"+balanceLabel.getText()+"', '"+expenseLabel.getText()+"', '"+incomeLabel.getText()+ "')";
        PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
      
        closeConnection(connection);
    } catch (SQLException e) {
        System.err.println("Error inserting data: " + e.getMessage());
        
    }
    
    }




    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        LogOut = new javax.swing.JToggleButton();
        expenseLabel = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        balanceLabel = new javax.swing.JLabel();
        incomeLabel = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        descriptionTextField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        entryTable = new javax.swing.JTable();
        amountTextField = new javax.swing.JTextField();
        amount_Label = new javax.swing.JLabel();
        DateChooser = new com.toedter.calendar.JDateChooser();
        jLabel2 = new javax.swing.JLabel();
        showhistory = new javax.swing.JButton();
        clearhistory = new javax.swing.JButton();
        Type = new javax.swing.JComboBox<>();
        type_of1 = new javax.swing.JButton();
        Category = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(129, 201, 252));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/loginform/icon/kharcha_logo.jpg"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 473, 511));

        LogOut.setBackground(new java.awt.Color(255, 0, 0));
        LogOut.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        LogOut.setForeground(new java.awt.Color(255, 255, 255));
        LogOut.setText("LOGOUT");
        LogOut.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        LogOut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        LogOut.setDebugGraphicsOptions(javax.swing.DebugGraphics.LOG_OPTION);
        LogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogOutActionPerformed(evt);
            }
        });
        jPanel1.add(LogOut, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 0, 111, -1));

        expenseLabel.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        expenseLabel.setForeground(new java.awt.Color(255, 0, 0));
        expenseLabel.setText("₹ 0.00");
        jPanel1.add(expenseLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 460, 121, -1));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel3.setText("INCOME");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 440, 83, -1));

        jLabel4.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel4.setText("BALANCE");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 440, 100, -1));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel5.setText("EXPENSE");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 440, 102, -1));

        balanceLabel.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        balanceLabel.setForeground(new java.awt.Color(255, 102, 0));
        balanceLabel.setText("₹0.00");
        jPanel1.add(balanceLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 460, 200, -1));

        incomeLabel.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        incomeLabel.setForeground(new java.awt.Color(0, 153, 0));
        incomeLabel.setText("₹ 0.00");
        jPanel1.add(incomeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 460, 122, -1));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jLabel9.setText("DATE :");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 100, -1, -1));

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jLabel10.setText("DESCRIPTION :");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 140, 100, -1));

        descriptionTextField.setFont(descriptionTextField.getFont().deriveFont(descriptionTextField.getFont().getStyle() | java.awt.Font.BOLD, descriptionTextField.getFont().getSize()+2));
        descriptionTextField.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel1.add(descriptionTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 140, 235, -1));

        jLabel8.setBackground(new java.awt.Color(51, 255, 51));
        jLabel8.setFont(new java.awt.Font("Bookman Old Style", 1, 24)); // NOI18N
        jLabel8.setText("FILL UP YOUR KHARCHA");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(524, 37, 354, -1));

        entryTable.setAutoCreateRowSorter(true);
        entryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "DATE", "DESCRIPTION", "AMOUNT", "TYPE", "CATEGORY"
            }
        ));
        entryTable.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                entryTableComponentShown(evt);
            }
        });
        jScrollPane1.setViewportView(entryTable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 210, 492, 224));

        amountTextField.setFont(amountTextField.getFont().deriveFont(amountTextField.getFont().getStyle() | java.awt.Font.BOLD, amountTextField.getFont().getSize()+2));
        amountTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                amountTextFieldActionPerformed(evt);
            }
        });
        jPanel1.add(amountTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 100, 133, -1));

        amount_Label.setBackground(new java.awt.Color(255, 255, 255));
        amount_Label.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        amount_Label.setText("AMOUNT :");
        jPanel1.add(amount_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 100, -1, -1));
        jPanel1.add(DateChooser, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 100, 130, 30));

        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel2.setText("₹ ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 100, 20, 20));

        showhistory.setText("HISTORY");
        showhistory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showhistoryActionPerformed(evt);
            }
        });
        jPanel1.add(showhistory, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 180, -1, -1));

        clearhistory.setText("CLEAR");
        clearhistory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearhistoryActionPerformed(evt);
            }
        });
        jPanel1.add(clearhistory, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 180, -1, -1));

        Type.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        Type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "TYPE", "INCOME", "EXPENSE" }));
        Type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TypeActionPerformed(evt);
            }
        });
        jPanel1.add(Type, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 140, -1, -1));

        type_of1.setBackground(new java.awt.Color(255, 153, 102));
        type_of1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        type_of1.setText("ADD");
        type_of1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        type_of1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        type_of1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                type_of1MouseClicked(evt);
            }
        });
        type_of1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                type_of1ActionPerformed(evt);
            }
        });
        jPanel1.add(type_of1, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 180, 70, -1));

        Category.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        Category.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CATEGORY", "BABY", "BEAUTY", "BILLS", "CAR", "CLOTHING", "EDUCATION", "ELECTRONICS", "ENTERTAINMENT", "FOOD", "HEALTH", "HOME", "INSURANCE", "LOAN", "PENSION", "RECHARGE", "SALARY", "SHOPPING", "SPORTS", "TRADE", "TAX", "TRANSPORTATION" }));
        Category.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CategoryActionPerformed(evt);
            }
        });
        jPanel1.add(Category, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 180, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 990, 490));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void LogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogOutActionPerformed
        adduserEntry();
     JOptionPane.showMessageDialog(this, "Logged out successfully.");
      dispose(); 

   
    }//GEN-LAST:event_LogOutActionPerformed


    
    
    
    private void amountTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_amountTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_amountTextFieldActionPerformed

    private void showhistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showhistoryActionPerformed
        addbalance();
      try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kharchaets", "root", "alister");
        Statement st = con.createStatement();
        String query = "select * from expenses";
        ResultSet rs = st.executeQuery(query);
        ResultSetMetaData rsmd = rs.getMetaData();
        DefaultTableModel model = (DefaultTableModel) entryTable.getModel();
       
        while (rs.next()) {
            String date = rs.getString(2);
            String description = rs.getString(3);
            String amount = rs.getString(4);
            String type = rs.getString(5);
            String category = rs.getString(6);

            String[] row = {date, description, amount, type,category};
            model.addRow(row);
        }
        st.close();
        con.close();
    } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
              
        }
     
    

    }//GEN-LAST:event_showhistoryActionPerformed

    private void TypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TypeActionPerformed
        // TODO add your handling code here:
        String type = Type.getSelectedItem().toString();
    }//GEN-LAST:event_TypeActionPerformed

    private void type_of1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_type_of1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_type_of1MouseClicked

    private void type_of1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_type_of1ActionPerformed
        // TODO add your handling code here:
        addEntry();
        addbalance();
    }//GEN-LAST:event_type_of1ActionPerformed

    private void CategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CategoryActionPerformed
        // TODO add your handling code here:
        String category = Category.getSelectedItem().toString();
    }//GEN-LAST:event_CategoryActionPerformed

    private void clearhistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearhistoryActionPerformed
        // TODO add your handling code here:
       ((DefaultTableModel)entryTable.getModel()).setRowCount(0);
    }//GEN-LAST:event_clearhistoryActionPerformed

    private void entryTableComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_entryTableComponentShown
        // TODO add your handling code here:
        
    }//GEN-LAST:event_entryTableComponentShown

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        // T       
        
    }//GEN-LAST:event_formComponentShown
// </editor-fold>                        
// </editor-fold>                        



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Category;
    private com.toedter.calendar.JDateChooser DateChooser;
    private javax.swing.JToggleButton LogOut;
    private javax.swing.JComboBox<String> Type;
    private javax.swing.JTextField amountTextField;
    private javax.swing.JLabel amount_Label;
    private javax.swing.JLabel balanceLabel;
    private javax.swing.JButton clearhistory;
    private javax.swing.JTextField descriptionTextField;
    private javax.swing.JTable entryTable;
    private javax.swing.JLabel expenseLabel;
    private javax.swing.JLabel incomeLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton showhistory;
    private javax.swing.JButton type_of1;
    // End of variables declaration//GEN-END:variables

    public static void main(String args[]){
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
               //</editor-fold>
               try {
                   new Main().setVisible(true);
               } catch (SQLException ex) {
                   Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
               }
        }
    }

    // End of variables declaration
    // Variables declaration - do not modify    

